class third_class():
    z = 7

    def print_third(self):
        print(self.z)