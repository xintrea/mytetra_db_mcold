class first_class():
    x = 5

    def print_first(self):
        print(self.x)