class second_class():
    y = 6
    def print_second(self):
        print(self.y)