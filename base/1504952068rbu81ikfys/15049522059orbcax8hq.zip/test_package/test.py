"""
Работа с пакетами
"""

from my_package import *                # учитывает только модули описанные в инструкции пакета (файл __init__.py)
                                        # __all__ = ["first_module", "second_module"]

#from my_package import third_module    # если импортировать напрямую, то работает
x = first_module.first_class()
x.print_first()

y = second_module.second_class()
y.print_second()

z = third_module.third_class()          # падает ошибка, т.к. данного модуля нет в объявлении пакета
z.print_third()



